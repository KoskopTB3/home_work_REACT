import { useState } from "react";
import useFetch from "./useFetch";
import styles from './CurrencyManager.module.css'

import ValueInputBlock from "./ValueInputBlock";
import CalculationBlock from "./CalculationBlock";

function CurrencyManager() {
//   const [exchangeRate, setExchangeRate] = useState(null);

  const { data, loading, error } = useFetch(
    "/NBUStatService/v1/statdirectory/exchange?json"
  );

  if (loading) {
    return <p>Завантаження продуктів...</p>;
  }
  if (error) {
    return (
      <p style={{ color: "red" }}>Помилка завантаження продуктів: {error}</p>
    );
  }

  function rateCalulation(userAmountMoney) {
	
  }
  

  return (
	<div className={styles.currencyManager}>
   <ValueInputBlock rateCalulation = {rateCalulation}/>
	<CalculationBlock dataExchange = {data}/>
	</div>
  );
}

export default CurrencyManager;
