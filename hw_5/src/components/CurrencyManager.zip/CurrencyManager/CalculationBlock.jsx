import { useState } from "react";
import styles from "./CurrencyManager.module.css";

function CalculationBlock({ dataExchange }) {
  const [selectedCurrencyId, setSelectedCurrencyId] = useState("");

  function onSelect(e) {
    const num = Number(e.target.value);
    setSelectedCurrencyId(Number(e.target.value));
  }

  const selectedCurrency = dataExchange.find(
    (currency) => currency.id === selectedCurrencyId
  );

  return (
    <div className={styles.calculationBlock}>
      <h2>Валюта {selectedCurrency?.cc}</h2>
      <div className={styles.selectContainer}>
        <select onChange={onSelect} value={selectedCurrencyId}>
          <option value="">Оберіть валюту</option>
          {dataExchange &&
            dataExchange.map((currency) => (
              <option key={currency.id} value={currency.id}>
                {currency.title}
              </option>
            ))}
        </select>
      </div>
    </div>
  );
}

export default CalculationBlock;
