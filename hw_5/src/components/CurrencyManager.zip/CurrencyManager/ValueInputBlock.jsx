import { useState } from "react";
import styles from './CurrencyManager.module.css'


function ValueInputBlock(rateCalulation) {
 const[inputValue,setInputValue] = useState('')
	
function handleInput(e) {
	setInputValue(e.target.value)
	rateCalulation(inputValue)
}
 
	return ( 
		<div className={styles.valueInputBlock}>
			<h2>Валюта гривня UAH</h2>
			<div className={styles.inputBlock}>
				<label>Введіть суму:
					<input value = {inputValue} type="number" onInput={handleInput}/>
				</label>
			</div>
		</div>
	 );
}

export default ValueInputBlock;
